#include <gtk/gtk.h>


void
on_backspace_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_CE_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_zero_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_seven_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_eight_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_nine_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_four_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_five_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_six_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_multiplication_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_one_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_two_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_three_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_substaction_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_dot_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_equal_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_addition_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_division_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_PLUSMINUS_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_CLEAR_clicked                       (GtkButton       *button,
                                        gpointer         user_data);
